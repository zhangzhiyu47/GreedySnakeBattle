var globalVariable_8c =
[
    [ "HIGH", "globalVariable_8c.html#a06f4596b463eb3c49c5fbaf8d53c6b86", null ],
    [ "isConfigFileOpenFail", "globalVariable_8c.html#aa533fc4d184458e9052b87a69d8e406b", null ],
    [ "originalTermios", "globalVariable_8c.html#ac202057a8bed4e3c46bd968ad096a491", null ],
    [ "outlineModeConfig", "globalVariable_8c.html#ad4cf03814d1b578be01dc7eda1996347", null ],
    [ "WIDE", "globalVariable_8c.html#ae9c2cc164f7558aa915192e48a4d230e", null ]
];