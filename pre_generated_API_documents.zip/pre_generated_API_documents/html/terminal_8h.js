var terminal_8h =
[
    [ "clearScreen", "terminal_8h.html#a9d7e8af417b6d543da691e9c0e2f6f9f", null ],
    [ "initTerminalSettings", "terminal_8h.html#a1b9010b0ad550ca4467e4ca506bc91e4", null ],
    [ "restoreTerminalSettings", "terminal_8h.html#aa0e5be3a02379220f3ce32873a36c5d0", null ],
    [ "terminal256ColorTablePainting", "terminal_8h.html#a82d95d54b00e96ca63c3dd5fa8d72b07", null ],
    [ "terminalSize", "terminal_8h.html#a1ee99b95286c20f059d063e24bc01c8a", null ]
];