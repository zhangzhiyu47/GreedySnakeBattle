var structPoint =
[
    [ "x", "structPoint.html#a8c779e11e694b20e0946105a9f5de842", null ],
    [ "y", "structPoint.html#a2e1b5fb2b2a83571f5c0bc0f66a73cf7", null ]
];