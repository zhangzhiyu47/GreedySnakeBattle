var group__OSAdapt =
[
    [ "linux_getch", "group__OSAdapt.html#ga21991acf1aba6035909461c9e7ff90e2", null ],
    [ "linux_kbhit", "group__OSAdapt.html#gafdd3512fd59d76568fd077086e3895d2", null ],
    [ "__attribute__", "group__OSAdapt.html#ga1a70bc9ff30788fe7ceeb823942615c8", null ],
    [ "__attribute__", "group__OSAdapt.html#ga8cf0124e69d23f31c0efcaba61b9774d", null ],
    [ "_snake_getch", "group__OSAdapt.html#ga7718066b167ee7d552fd7e1a987a12e5", null ],
    [ "_snake_kbhit", "group__OSAdapt.html#gabd42cb5b764d0052febbd6cde9d94e8c", null ],
    [ "disable_normal_input", "group__OSAdapt.html#gab24964fdbf0163fd68b7cfde981d0e31", null ],
    [ "enable_normal_input", "group__OSAdapt.html#ga418b098dfd5fd67e21ea0f6d30c6627e", null ],
    [ "get_buffered_input", "group__OSAdapt.html#gaea6d5018cf2471abec242ffa12822315", null ],
    [ "get_unbuffered_input", "group__OSAdapt.html#ga8394878343d9c77a7c108b714fc1e8ee", null ],
    [ "init_terminal_settings", "group__OSAdapt.html#ga729f169ee94ac6146444e514163e8e86", null ],
    [ "restore_terminal_settings", "group__OSAdapt.html#gae1417bdb53e4bf41cb65ed3a25f2e255", null ]
];