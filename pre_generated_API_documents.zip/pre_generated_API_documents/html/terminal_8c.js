var terminal_8c =
[
    [ "terminal256ColorTablePainting", "terminal_8c.html#a82d95d54b00e96ca63c3dd5fa8d72b07", null ],
    [ "terminalSize", "terminal_8c.html#a1ee99b95286c20f059d063e24bc01c8a", null ]
];