var signalCapture_8h =
[
    [ "childProcessCatchINT", "group__SignalCapture.html#ga5189450f8a7310458ba777d7abb28b0a", null ],
    [ "childProcessCatchUSR1", "group__SignalCapture.html#ga15e11345e0ed0f8bc838055b83392eff", null ],
    [ "childProcessCatchUSR2", "group__SignalCapture.html#ga99a6a57550bc51d984b4d72af68c8793", null ],
    [ "fatherProcessCatchCHLD", "group__SignalCapture.html#ga2754d2b299b7c121010e7c813f7d14c3", null ],
    [ "fatherProcessCatchINT", "group__SignalCapture.html#ga8f0231b3b157dd242bb7cf83f66ae6a2", null ]
];