var index =
[
    [ "目录", "index.html#autotoc_md48", null ],
    [ "项目概述", "index.html#autotoc_md50", null ],
    [ "项目许可证", "index.html#autotoc_md51", [
      [ "MIT许可证", "index.html#autotoc_md52", null ],
      [ "​授权范围", "index.html#autotoc_md53", null ],
      [ "​条件限制", "index.html#autotoc_md54", null ],
      [ "​免责声明", "index.html#autotoc_md55", null ],
      [ "查看许可证", "index.html#autotoc_md56", null ]
    ] ],
    [ "游戏特点", "index.html#autotoc_md58", null ],
    [ "游戏控制", "index.html#autotoc_md59", null ],
    [ "游戏元素", "index.html#autotoc_md60", null ],
    [ "游戏流程", "index.html#autotoc_md61", null ],
    [ "离线模式", "index.html#autotoc_md63", null ],
    [ "签名验证", "index.html#autotoc_md65", [
      [ "预备", "index.html#autotoc_md66", [
        [ "安装GPG", "index.html#autotoc_md67", [
          [ "Windows", "index.html#autotoc_md68", null ],
          [ "Linux/MacOS", "index.html#autotoc_md69", null ]
        ] ]
      ] ],
      [ "1.解压签名文件", "index.html#autotoc_md70", null ],
      [ "2.导入公钥(位于项目根目录下)：", "index.html#autotoc_md71", null ],
      [ "3.验证签名：", "index.html#autotoc_md72", null ],
      [ "自动化检查脚本", "index.html#autotoc_md74", [
        [ "Windows", "index.html#autotoc_md75", null ],
        [ "Linux/MacOS", "index.html#autotoc_md76", [
          [ "1. 脚本内容", "index.html#autotoc_md77", null ],
          [ "2. 使用方法", "index.html#autotoc_md78", null ]
        ] ]
      ] ]
    ] ],
    [ "Windows下游戏需要", "index.html#autotoc_md80", [
      [ "下载Cygwin", "index.html#autotoc_md81", null ],
      [ "安装Cygwin", "index.html#autotoc_md82", [
        [ "基本安装步骤", "index.html#autotoc_md83", null ],
        [ "选择镜像站点", "index.html#autotoc_md84", null ],
        [ "选择要安装的包", "index.html#autotoc_md85", null ]
      ] ],
      [ "安装后的配置", "index.html#autotoc_md86", [
        [ "环境变量设置", "index.html#autotoc_md87", null ],
        [ "启动Cygwin", "index.html#autotoc_md88", null ]
      ] ],
      [ "验证安装", "index.html#autotoc_md89", null ],
      [ "安装额外包（后续）", "index.html#autotoc_md90", null ],
      [ "使用Cygwin开发", "index.html#autotoc_md91", null ],
      [ "注意事项", "index.html#autotoc_md92", null ]
    ] ],
    [ "游戏接口", "index.html#autotoc_md94", [
      [ "连接选项", "index.html#autotoc_md95", null ],
      [ "函数原型", "index.html#autotoc_md96", null ],
      [ "参数", "index.html#autotoc_md97", null ],
      [ "返回值", "index.html#autotoc_md98", null ],
      [ "使用示例", "index.html#autotoc_md99", null ],
      [ "代码标准", "index.html#autotoc_md100", null ]
    ] ],
    [ "构建与安装", "index.html#autotoc_md102", [
      [ "构建要求", "index.html#autotoc_md103", null ],
      [ "构建步骤", "index.html#autotoc_md104", null ],
      [ "执行Make进行安装/卸载", "index.html#autotoc_md105", [
        [ "安装", "index.html#autotoc_md106", null ],
        [ "卸载", "index.html#autotoc_md107", null ]
      ] ],
      [ "安装内容", "index.html#autotoc_md108", null ]
    ] ],
    [ "跨平台支持", "index.html#autotoc_md110", null ],
    [ "已知问题", "index.html#autotoc_md112", null ],
    [ "未来计划", "index.html#autotoc_md113", null ],
    [ "代码风格总结与贡献指南", "index.html#autotoc_md114", [
      [ "1. 注释风格（Javadoc 风格）", "index.html#autotoc_md115", [
        [ "**规则**：", "index.html#autotoc_md116", null ],
        [ "贡献者注意事项**：", "index.html#autotoc_md117", null ]
      ] ],
      [ "2.命名规则（Qt风格）", "index.html#autotoc_md119", [
        [ "**规则**：", "index.html#autotoc_md120", null ],
        [ "贡献者注意事项**：", "index.html#autotoc_md121", null ]
      ] ],
      [ "3. 代码风格（Qt风格）", "index.html#autotoc_md123", [
        [ "**规则**：", "index.html#autotoc_md124", null ],
        [ "贡献者注意事项**：", "index.html#autotoc_md125", null ]
      ] ],
      [ "总结：贡献者应遵循的规则", "index.html#autotoc_md127", null ],
      [ "如何检查？", "index.html#autotoc_md128", null ]
    ] ]
];