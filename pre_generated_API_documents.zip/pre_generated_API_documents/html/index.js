var index =
[
    [ "Table of Contents", "index.html#autotoc_md48", null ],
    [ "Project Overview", "index.html#autotoc_md50", null ],
    [ "Project License", "index.html#autotoc_md51", [
      [ "MIT License", "index.html#autotoc_md52", null ],
      [ "Authorization Scope", "index.html#autotoc_md53", null ],
      [ "Conditions", "index.html#autotoc_md54", null ],
      [ "Disclaimer", "index.html#autotoc_md55", null ],
      [ "View License", "index.html#autotoc_md56", null ]
    ] ],
    [ "Signature Verification", "index.html#autotoc_md58", [
      [ "Prerequisites", "index.html#autotoc_md59", [
        [ "Install GPG", "index.html#autotoc_md60", [
          [ "Windows", "index.html#autotoc_md61", null ],
          [ "Linux/macOS", "index.html#autotoc_md62", null ]
        ] ]
      ] ],
      [ "Extracting the Signature Files", "index.html#autotoc_md63", null ],
      [ "Import Public Key (located in the project root directory):", "index.html#autotoc_md64", null ],
      [ "Verify Signatures:", "index.html#autotoc_md65", null ],
      [ "Automated Verification Scripts", "index.html#autotoc_md67", [
        [ "Windows", "index.html#autotoc_md68", null ],
        [ "Linux/macOS", "index.html#autotoc_md69", [
          [ "1. Script Content", "index.html#autotoc_md70", null ],
          [ "2. Usage", "index.html#autotoc_md71", null ],
          [ "3. Script Features", "index.html#autotoc_md72", null ]
        ] ]
      ] ]
    ] ],
    [ "Game Features", "index.html#autotoc_md74", null ],
    [ "Game Controls", "index.html#autotoc_md75", null ],
    [ "Game Elements", "index.html#autotoc_md76", null ],
    [ "Game Flow", "index.html#autotoc_md77", null ],
    [ "Offline Mode", "index.html#autotoc_md79", null ],
    [ "Game Interface", "index.html#autotoc_md81", [
      [ "Linking Options", "index.html#autotoc_md82", null ],
      [ "Function Prototype", "index.html#autotoc_md83", null ],
      [ "Parameters", "index.html#autotoc_md84", null ],
      [ "Return Values", "index.html#autotoc_md85", null ],
      [ "Example", "index.html#autotoc_md86", null ],
      [ "Code Standards", "index.html#autotoc_md87", null ]
    ] ],
    [ "Build & Installation", "index.html#autotoc_md89", [
      [ "Build Requirements", "index.html#autotoc_md90", null ],
      [ "Build Steps", "index.html#autotoc_md91", null ],
      [ "Install & Uninstall", "index.html#autotoc_md92", [
        [ "Install", "index.html#autotoc_md93", null ],
        [ "Uninstall", "index.html#autotoc_md94", null ]
      ] ],
      [ "Installation Contents", "index.html#autotoc_md95", null ]
    ] ],
    [ "Cross-Platform Support", "index.html#autotoc_md97", null ],
    [ "Known Issues", "index.html#autotoc_md99", null ],
    [ "Future Plans", "index.html#autotoc_md100", null ],
    [ "Code Style Summary & Contribution Guidelines", "index.html#autotoc_md101", [
      [ "1. Comment Style (Javadoc Style)", "index.html#autotoc_md102", [
        [ "Rules:", "index.html#autotoc_md103", null ],
        [ "Contributor Notes:", "index.html#autotoc_md104", null ]
      ] ],
      [ "2. Naming Conventions (Qt Style)", "index.html#autotoc_md106", [
        [ "Rules:", "index.html#autotoc_md107", null ],
        [ "Contributor Notes:", "index.html#autotoc_md108", null ]
      ] ],
      [ "3. Code Style (Qt Style)", "index.html#autotoc_md110", [
        [ "Rules:", "index.html#autotoc_md111", null ],
        [ "Contributor Notes:", "index.html#autotoc_md112", null ]
      ] ],
      [ "Summary: Rules for Contributors", "index.html#autotoc_md114", null ],
      [ "How to Check?", "index.html#autotoc_md115", null ]
    ] ],
    [ "贪吃蛇大作战", "index.html#autotoc_md116", [
      [ "目录", "index.html#autotoc_md117", null ],
      [ "项目概述", "index.html#autotoc_md119", null ],
      [ "项目许可证", "index.html#autotoc_md120", [
        [ "MIT许可证", "index.html#autotoc_md121", null ],
        [ "​授权范围", "index.html#autotoc_md122", null ],
        [ "​条件限制", "index.html#autotoc_md123", null ],
        [ "​免责声明", "index.html#autotoc_md124", null ],
        [ "查看许可证", "index.html#autotoc_md125", null ]
      ] ],
      [ "签名验证", "index.html#autotoc_md127", [
        [ "预备", "index.html#autotoc_md128", [
          [ "安装GPG", "index.html#autotoc_md129", [
            [ "Windows", "index.html#autotoc_md130", null ],
            [ "Linux/macOS", "index.html#autotoc_md131", null ]
          ] ]
        ] ],
        [ "1.解压签名文件", "index.html#autotoc_md132", null ],
        [ "2.导入公钥(位于项目根目录下)：", "index.html#autotoc_md133", null ],
        [ "3.验证签名：", "index.html#autotoc_md134", null ],
        [ "自动化检查脚本", "index.html#autotoc_md136", [
          [ "Windows", "index.html#autotoc_md137", null ],
          [ "Linux/macOS", "index.html#autotoc_md138", [
            [ "1. 脚本内容", "index.html#autotoc_md139", null ],
            [ "2. 使用方法", "index.html#autotoc_md140", null ],
            [ "3. 脚本特点", "index.html#autotoc_md141", null ]
          ] ]
        ] ]
      ] ],
      [ "游戏特点", "index.html#autotoc_md143", null ],
      [ "游戏控制", "index.html#autotoc_md144", null ],
      [ "游戏元素", "index.html#autotoc_md145", null ],
      [ "游戏流程", "index.html#autotoc_md146", null ],
      [ "离线模式", "index.html#autotoc_md148", null ],
      [ "游戏接口", "index.html#autotoc_md150", [
        [ "连接选项", "index.html#autotoc_md151", null ],
        [ "函数原型", "index.html#autotoc_md152", null ],
        [ "参数", "index.html#autotoc_md153", null ],
        [ "返回值", "index.html#autotoc_md154", null ],
        [ "使用示例", "index.html#autotoc_md155", null ],
        [ "代码标准", "index.html#autotoc_md156", null ]
      ] ],
      [ "构建与安装", "index.html#autotoc_md158", [
        [ "构建要求", "index.html#autotoc_md159", null ],
        [ "构建步骤", "index.html#autotoc_md160", null ],
        [ "执行Make进行安装/卸载", "index.html#autotoc_md161", [
          [ "安装", "index.html#autotoc_md162", null ],
          [ "卸载", "index.html#autotoc_md163", null ]
        ] ],
        [ "安装内容", "index.html#autotoc_md164", null ]
      ] ],
      [ "跨平台支持", "index.html#autotoc_md166", null ],
      [ "已知问题", "index.html#autotoc_md168", null ],
      [ "未来计划", "index.html#autotoc_md169", null ],
      [ "代码风格总结与贡献指南", "index.html#autotoc_md170", [
        [ "1. 注释风格（Javadoc 风格）", "index.html#autotoc_md171", [
          [ "**规则**：", "index.html#autotoc_md172", null ],
          [ "贡献者注意事项**：", "index.html#autotoc_md173", null ]
        ] ],
        [ "2.命名规则（Qt风格）", "index.html#autotoc_md175", [
          [ "**规则**：", "index.html#autotoc_md176", null ],
          [ "贡献者注意事项**：", "index.html#autotoc_md177", null ]
        ] ],
        [ "3. 代码风格（Qt风格）", "index.html#autotoc_md179", [
          [ "**规则**：", "index.html#autotoc_md180", null ],
          [ "贡献者注意事项**：", "index.html#autotoc_md181", null ]
        ] ],
        [ "总结：贡献者应遵循的规则", "index.html#autotoc_md183", null ],
        [ "如何检查？", "index.html#autotoc_md184", null ]
      ] ]
    ] ]
];