var annotated_dup =
[
    [ "GameAllRunningData", "structGameAllRunningData.html", "structGameAllRunningData" ],
    [ "GameConfig", "structGameConfig.html", "structGameConfig" ],
    [ "Point", "structPoint.html", "structPoint" ]
];