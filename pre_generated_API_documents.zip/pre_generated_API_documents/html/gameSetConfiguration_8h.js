var gameSetConfiguration_8h =
[
    [ "setConfig_foodNum", "group__SetConfig.html#ga2e77b8baabbda481fa791312590927bb", null ],
    [ "setConfig_isEnableEatSlfGmOver", "group__SetConfig.html#ga3a01acb5a5ddc27d147747660b76e176", null ],
    [ "setConfig_isEnableObs", "group__SetConfig.html#ga0e9037d51bd4b28d6baababedf3642b8", null ],
    [ "setConfig_minScrOpnVctryPnt", "group__SetConfig.html#ga5998f86cc5c1f85dcbca64b5a1ca846b", null ],
    [ "setConfig_scrnHigh_scrnWide", "group__SetConfig.html#ga34185da3eb52995bcf32f4d8468a68c4", null ],
    [ "setConfig_speed", "group__SetConfig.html#ga7c1e27b1c159e992cfa1649f16114fa4", null ],
    [ "setConfig_wallNum", "group__SetConfig.html#ga7a2143a54f88a5f2ee485f0e61b264e9", null ],
    [ "setConfig_wordColr_scrnColr", "group__SetConfig.html#gad9799173956e460b7953078ed912d85f", null ],
    [ "setConfigAllToDefault", "group__SetConfig.html#gaff3267de733108f8386546629f3c3bf2", null ]
];