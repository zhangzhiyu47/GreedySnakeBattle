var userInterfaceBeforeGameStarts_8h =
[
    [ "configureGame", "userInterfaceBeforeGameStarts_8h.html#af2a1d489174d001b9c268b16378a174c", null ],
    [ "firstLoginToGameLoading", "userInterfaceBeforeGameStarts_8h.html#afb3cb8d76e17e6273b7643300b17e726", null ],
    [ "gameIntroduction", "userInterfaceBeforeGameStarts_8h.html#aa262db24645e5922376802ff5d1c661e", null ],
    [ "gameStartupLoading", "userInterfaceBeforeGameStarts_8h.html#a4c54ea2f9428155f24727b7abc84d05a", null ],
    [ "showGameMenu", "userInterfaceBeforeGameStarts_8h.html#abb5424e676aaf6aa0d015bbce639bc11", null ]
];