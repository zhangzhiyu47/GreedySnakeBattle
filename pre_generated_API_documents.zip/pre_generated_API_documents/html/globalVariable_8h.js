var globalVariable_8h =
[
    [ "HIGH", "globalVariable_8h.html#a06f4596b463eb3c49c5fbaf8d53c6b86", null ],
    [ "isConfigFileOpenFail", "globalVariable_8h.html#aa533fc4d184458e9052b87a69d8e406b", null ],
    [ "outlineModeConfig", "globalVariable_8h.html#ad4cf03814d1b578be01dc7eda1996347", null ],
    [ "WIDE", "globalVariable_8h.html#ae9c2cc164f7558aa915192e48a4d230e", null ]
];