var GameAllRunningData_8h =
[
    [ "GameAllRunningData", "structGameAllRunningData.html", "structGameAllRunningData" ],
    [ "GameAllRunningData", "GameAllRunningData_8h.html#afd29c49c613e516a1a983ab60a5cccfb", null ]
];