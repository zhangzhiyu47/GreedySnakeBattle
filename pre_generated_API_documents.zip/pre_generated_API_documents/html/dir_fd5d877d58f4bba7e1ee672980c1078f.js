var dir_fd5d877d58f4bba7e1ee672980c1078f =
[
    [ "Functions", "dir_463b1d1fa67ba476597f6a13b73801e5.html", "dir_463b1d1fa67ba476597f6a13b73801e5" ],
    [ "GlobalVariable", "dir_8886349ebdb9528c7e7fb636392e8ffb.html", "dir_8886349ebdb9528c7e7fb636392e8ffb" ],
    [ "Struct", "dir_8bd65b0db75fd617230c71204953f36b.html", "dir_8bd65b0db75fd617230c71204953f36b" ],
    [ "TypeDefine", "dir_609a67d518112aa526a32c0af84fb12b.html", "dir_609a67d518112aa526a32c0af84fb12b" ],
    [ "GreedySnakeBattleGameExternalInterface.h", "GreedySnakeBattleGameExternalInterface_8h.html", "GreedySnakeBattleGameExternalInterface_8h" ]
];