var standardIO_8c =
[
    [ "blockWaitUserEnter", "standardIO_8c.html#a9f7e7b62150367262361204d1e2f74c2", null ],
    [ "disableNormalInput", "standardIO_8c.html#acb45a1cc0c41157397f5469cf7a5d752", null ],
    [ "enableNormalInput", "standardIO_8c.html#a12141e910d803598c134f9238d2bff8d", null ]
];