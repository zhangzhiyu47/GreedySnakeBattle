var standardIO_8c =
[
    [ "blockWaitUserEnter", "standardIO_8c.html#a9f7e7b62150367262361204d1e2f74c2", null ],
    [ "disableNormalInput", "standardIO_8c.html#acb45a1cc0c41157397f5469cf7a5d752", null ],
    [ "enableNormalInput", "standardIO_8c.html#a12141e910d803598c134f9238d2bff8d", null ],
    [ "linuxKbhit", "standardIO_8c.html#adbee67c298d66779a11a599e515558d4", null ],
    [ "trulyDisableNormalInput", "standardIO_8c.html#a32a50d608e7a5ff0411f1599ca910439", null ],
    [ "trulyEnableNormalInput", "standardIO_8c.html#ae8443c2d55b54a7d02ebac7d4837fb95", null ]
];