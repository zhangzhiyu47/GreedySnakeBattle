var GreedySnakeBattleGameExternalInterface_8h =
[
    [ "GreedySnakeBattleGameExternalInterface", "GreedySnakeBattleGameExternalInterface_8h.html#a07b30632007b10dc759236858d9e57f1", null ],
    [ "SNAKE_BLOCK", "GreedySnakeBattleGameExternalInterface_8h.html#a03050ce9ad8ec52058e545c054cf9eae", null ],
    [ "SNAKE_UNBLOCK", "GreedySnakeBattleGameExternalInterface_8h.html#a45708c80aae47f2c7a0fd116ef51efcf", null ]
];