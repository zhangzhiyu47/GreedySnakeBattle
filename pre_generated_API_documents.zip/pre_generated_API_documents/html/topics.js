var topics =
[
    [ "Operating system adaptation function group", "group__OSAdapt.html", "group__OSAdapt" ],
    [ "Greedy Snake Battle Game Settings", "group__SetConfig.html", "group__SetConfig" ],
    [ "Signal capture", "group__SignalCapture.html", "group__SignalCapture" ]
];