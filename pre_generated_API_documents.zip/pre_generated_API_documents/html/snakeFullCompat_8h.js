var snakeFullCompat_8h =
[
    [ "clearAll", "snakeFullCompat_8h.html#ae4432cb650ea8991d6f3cf44511e8144", null ],
    [ "HIDE_CURSOR", "snakeFullCompat_8h.html#afda389c3c8b482e025dc765d250a5a0d", null ],
    [ "linux_getch", "group__OSAdapt.html#ga21991acf1aba6035909461c9e7ff90e2", null ],
    [ "linux_kbhit", "group__OSAdapt.html#gafdd3512fd59d76568fd077086e3895d2", null ],
    [ "printf_color", "snakeFullCompat_8h.html#a1bd9abaa54ae9d0d14f10c72374e14e8", null ],
    [ "SET_CURSOR_POS", "snakeFullCompat_8h.html#a9bcdac430bc52753ffb41bf60764ec91", null ],
    [ "SHOW_CURSOR", "snakeFullCompat_8h.html#ade9c2a563b11982d9d657d3ac3a0ceb1", null ],
    [ "SNAKE_OS_WINDOWS", "snakeFullCompat_8h.html#a53a680f748bded67be8089ab1bbca636", null ],
    [ "_snake_getch", "group__OSAdapt.html#ga7718066b167ee7d552fd7e1a987a12e5", null ],
    [ "_snake_kbhit", "group__OSAdapt.html#gabd42cb5b764d0052febbd6cde9d94e8c", null ],
    [ "disable_normal_input", "group__OSAdapt.html#gab24964fdbf0163fd68b7cfde981d0e31", null ],
    [ "enable_normal_input", "group__OSAdapt.html#ga418b098dfd5fd67e21ea0f6d30c6627e", null ],
    [ "get_buffered_input", "group__OSAdapt.html#gaea6d5018cf2471abec242ffa12822315", null ],
    [ "get_unbuffered_input", "group__OSAdapt.html#ga8394878343d9c77a7c108b714fc1e8ee", null ],
    [ "init_terminal_settings", "group__OSAdapt.html#ga729f169ee94ac6146444e514163e8e86", null ],
    [ "restore_terminal_settings", "group__OSAdapt.html#gae1417bdb53e4bf41cb65ed3a25f2e255", null ]
];