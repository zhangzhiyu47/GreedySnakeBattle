var obstacleSnake_8c =
[
    [ "obsEatFood", "obstacleSnake_8c.html#ab738497e815437794b5de1faf4aa80a4", null ],
    [ "obsEatWallsOrUserSnake", "obstacleSnake_8c.html#af6d4e56c0a4a642c5e5b448e56072cdc", null ],
    [ "obsInit", "obstacleSnake_8c.html#a2f6e40a7612f2d0b2c0430dfba37d35c", null ],
    [ "obsMove", "obstacleSnake_8c.html#af424fa8d10d40ea4a01a6181e26aa507", null ],
    [ "obsMoveDirecControl", "obstacleSnake_8c.html#abb235c1728c395dbc41f3fb85894aa3e", null ]
];