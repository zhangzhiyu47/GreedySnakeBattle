var userSnake_8h =
[
    [ "isUserSnakeEatObsSnake", "userSnake_8h.html#a3351c37ec6e4a50230dbc20d6bde8c92", null ],
    [ "isUserSnakeEatSelf", "userSnake_8h.html#a364a46c3f81e2f0e70d246e87bbbafbc", null ],
    [ "isUserSnakeEatWall", "userSnake_8h.html#a21066831bc671cd2e9e99e43fe404c54", null ],
    [ "userSnakeEatFood", "userSnake_8h.html#ad822f76f44eea9149083a0fa823f51ae", null ],
    [ "userSnakeMove", "userSnake_8h.html#a0ac59372daf37c105ee1df4fc06e7731", null ],
    [ "userSnakeMoveDirecControl", "userSnake_8h.html#aaab8f7612240e173d00b74cf1b7bdd35", null ]
];