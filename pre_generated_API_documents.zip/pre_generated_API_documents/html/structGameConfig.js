var structGameConfig =
[
    [ "foodNum", "structGameConfig.html#a62c3ddd92cf23e30619f0e737e499e74", null ],
    [ "histryHighestScr", "structGameConfig.html#afdb4ef43e26fee9db874276c03fe7251", null ],
    [ "isEnableEatSlfGmOver", "structGameConfig.html#afa2491abf3fc1deb31fd86db7498a2f4", null ],
    [ "isEnableObs", "structGameConfig.html#a2ef4b9e991958810e095b355d6b10a55", null ],
    [ "minScrOpnVctryPnt", "structGameConfig.html#a70d4af3105558c8193064f581dbb7d86", null ],
    [ "scrnColr", "structGameConfig.html#ac6d83e798f37711a95454c5eeb3d83cd", null ],
    [ "scrnHigh", "structGameConfig.html#a32c199cbbba0cf568746c954fabaf567", null ],
    [ "scrnWide", "structGameConfig.html#a85527a5d6bfaa890671ba9fea543fe0f", null ],
    [ "speed", "structGameConfig.html#a7b2a685507a316b03d7e44d138032e95", null ],
    [ "wallNum", "structGameConfig.html#aba7010ce0ab42593b7ffb35a18f23370", null ],
    [ "wordColr", "structGameConfig.html#a08e8265e2c7649d07f39ae0530cd4969", null ]
];