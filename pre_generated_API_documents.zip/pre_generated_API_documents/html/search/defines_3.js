var searchData=
[
  ['set_5fcursor_5fpos_0',['SET_CURSOR_POS',['../snakeFullCompat_8h.html#a9bcdac430bc52753ffb41bf60764ec91',1,'snakeFullCompat.h']]],
  ['show_5fcursor_1',['SHOW_CURSOR',['../snakeFullCompat_8h.html#ade9c2a563b11982d9d657d3ac3a0ceb1',1,'snakeFullCompat.h']]],
  ['snake_5fos_5fwindows_2',['SNAKE_OS_WINDOWS',['../snakeFullCompat_8h.html#a53a680f748bded67be8089ab1bbca636',1,'snakeFullCompat.h']]]
];
