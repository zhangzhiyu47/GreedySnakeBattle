var searchData=
[
  ['restriction_0',['restriction',['../LICENSE_8txt.html#ac0e1e4a858a6a19c5392f7f6d29f969c',1,'LICENSE.txt']]]
];
