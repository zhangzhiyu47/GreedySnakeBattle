var searchData=
[
  ['gameallrunningdata_0',['GameAllRunningData',['../GameAllRunningData_8h.html#afd29c49c613e516a1a983ab60a5cccfb',1,'GameAllRunningData.h']]],
  ['gameconfig_1',['GameConfig',['../GameConfig_8h.html#aa64fdb8a1b9c72973d80bb0dd73c757e',1,'GameConfig.h']]]
];
