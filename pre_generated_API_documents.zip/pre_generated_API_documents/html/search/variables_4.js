var searchData=
[
  ['implied_0',['IMPLIED',['../LICENSE_8txt.html#ab0624cdd79a1b72ae3e8cb7b147149da',1,'LICENSE.txt']]],
  ['isconfigfileopenfail_1',['isConfigFileOpenFail',['../globalVariable_8c.html#aa533fc4d184458e9052b87a69d8e406b',1,'isConfigFileOpenFail:&#160;globalVariable.c'],['../globalVariable_8h.html#aa533fc4d184458e9052b87a69d8e406b',1,'isConfigFileOpenFail:&#160;globalVariable.c']]],
  ['isenableeatslfgmover_2',['isEnableEatSlfGmOver',['../structGameAllRunningData.html#a70a0d1a0bad3b425fc5dc94bd0931c8c',1,'GameAllRunningData::isEnableEatSlfGmOver'],['../structGameConfig.html#afa2491abf3fc1deb31fd86db7498a2f4',1,'GameConfig::isEnableEatSlfGmOver']]],
  ['isenableobs_3',['isEnableObs',['../structGameAllRunningData.html#a416fb5fb0fbeb677bb50fff85841a4d2',1,'GameAllRunningData::isEnableObs'],['../structGameConfig.html#a2ef4b9e991958810e095b355d6b10a55',1,'GameConfig::isEnableObs']]]
];
