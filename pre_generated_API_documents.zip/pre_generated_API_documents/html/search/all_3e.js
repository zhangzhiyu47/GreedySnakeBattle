var searchData=
[
  ['选择要安装的包_0',['选择要安装的包',['../index.html#autotoc_md85',1,'']]],
  ['选择镜像站点_1',['选择镜像站点',['../index.html#autotoc_md84',1,'']]]
];
