var searchData=
[
  ['initallgamedata_0',['initAllGameData',['../gameStartupRelated_8c.html#a32bc30565280b8197a1c4e99927b0b66',1,'initAllGameData(GameAllRunningData *data):&#160;gameStartupRelated.c'],['../gameStartupRelated_8h.html#a32bc30565280b8197a1c4e99927b0b66',1,'initAllGameData(GameAllRunningData *data):&#160;gameStartupRelated.c']]],
  ['initterminalsettings_1',['initTerminalSettings',['../terminal_8h.html#a1b9010b0ad550ca4467e4ca506bc91e4',1,'initTerminalSettings():&#160;terminal.c'],['../terminal_8c.html#a1b9010b0ad550ca4467e4ca506bc91e4',1,'initTerminalSettings():&#160;terminal.c']]],
  ['isusersnakeeatobssnake_2',['isUserSnakeEatObsSnake',['../userSnake_8h.html#a3351c37ec6e4a50230dbc20d6bde8c92',1,'isUserSnakeEatObsSnake(const GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a3351c37ec6e4a50230dbc20d6bde8c92',1,'isUserSnakeEatObsSnake(const GameAllRunningData *data):&#160;userSnake.c']]],
  ['isusersnakeeatself_3',['isUserSnakeEatSelf',['../userSnake_8h.html#a364a46c3f81e2f0e70d246e87bbbafbc',1,'isUserSnakeEatSelf(const GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a364a46c3f81e2f0e70d246e87bbbafbc',1,'isUserSnakeEatSelf(const GameAllRunningData *data):&#160;userSnake.c']]],
  ['isusersnakeeatwall_4',['isUserSnakeEatWall',['../userSnake_8h.html#a21066831bc671cd2e9e99e43fe404c54',1,'isUserSnakeEatWall(const GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a21066831bc671cd2e9e99e43fe404c54',1,'isUserSnakeEatWall(const GameAllRunningData *data):&#160;userSnake.c']]]
];
