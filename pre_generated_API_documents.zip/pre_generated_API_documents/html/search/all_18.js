var searchData=
[
  ['table_20of_20contents_0',['Table of Contents',['../index.html#autotoc_md48',1,'']]],
  ['terminal_2ec_1',['terminal.c',['../terminal_8c.html',1,'']]],
  ['terminal_2eh_2',['terminal.h',['../terminal_8h.html',1,'']]],
  ['terminal256colortablepainting_3',['terminal256ColorTablePainting',['../terminal_8h.html#a82d95d54b00e96ca63c3dd5fa8d72b07',1,'terminal256ColorTablePainting(const GameConfig *config):&#160;terminal.c'],['../terminal_8c.html#a82d95d54b00e96ca63c3dd5fa8d72b07',1,'terminal256ColorTablePainting(const GameConfig *config):&#160;terminal.c']]],
  ['terminalsize_4',['terminalSize',['../terminal_8h.html#a1ee99b95286c20f059d063e24bc01c8a',1,'terminalSize():&#160;terminal.c'],['../terminal_8c.html#a1ee99b95286c20f059d063e24bc01c8a',1,'terminalSize():&#160;terminal.c']]],
  ['the_20project_20root_20directory_20_3a_5',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['the_20signature_20files_6',['1. Extracting the Signature Files',['../index.html#autotoc_md63',1,'']]],
  ['the_20snake_20battle_7',['the Snake Battle',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md10',1,'Introduction to the Snake Battle'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md34',1,'Introduction to the Snake Battle']]],
  ['this_20function_8',['this function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md1',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md25',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md22',1,'Example of this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md46',1,'Example of this function']]],
  ['to_20check_20strong_9',['&lt;strong&gt;How to Check?&lt;/strong&gt;',['../index.html#autotoc_md115',1,'']]],
  ['to_20the_20snake_20battle_10',['to the Snake Battle',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md10',1,'Introduction to the Snake Battle'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md34',1,'Introduction to the Snake Battle']]],
  ['todo_20list_11',['Todo List',['../todo.html',1,'']]],
  ['todos_12',['TODOs',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md14',1,'BUGs and TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md38',1,'BUGs and TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md16',1,'TODOs'],['../todo.html#_todo000002',1,'TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md40',1,'TODOs'],['../todo.html#_todo000006',1,'TODOs']]],
  ['typedef_2eh_13',['typedef.h',['../typedef_8h.html',1,'']]]
];
