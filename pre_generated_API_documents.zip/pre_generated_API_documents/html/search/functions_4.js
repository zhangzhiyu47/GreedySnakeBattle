var searchData=
[
  ['fatherprocesscatchchld_0',['fatherProcessCatchCHLD',['../group__SignalCapture.html#ga2754d2b299b7c121010e7c813f7d14c3',1,'fatherProcessCatchCHLD(int signum):&#160;signalCapture.c'],['../group__SignalCapture.html#ga2754d2b299b7c121010e7c813f7d14c3',1,'fatherProcessCatchCHLD(int signum):&#160;signalCapture.c']]],
  ['fatherprocesscatchint_1',['fatherProcessCatchINT',['../group__SignalCapture.html#ga8f0231b3b157dd242bb7cf83f66ae6a2',1,'fatherProcessCatchINT(int signum):&#160;signalCapture.c'],['../group__SignalCapture.html#ga8f0231b3b157dd242bb7cf83f66ae6a2',1,'fatherProcessCatchINT(int signum):&#160;signalCapture.c']]],
  ['files_2',['files',['../LICENSE_8txt.html#a953a9e6174b7f8cab75d34ed6ae02c98',1,'LICENSE.txt']]],
  ['firstlogintogameloading_3',['firstLoginToGameLoading',['../userInterfaceBeforeGameStarts_8h.html#afb3cb8d76e17e6273b7643300b17e726',1,'firstLoginToGameLoading():&#160;userInterfaceBeforeGameStarts.c'],['../userInterfaceBeforeGameStarts_8c.html#afb3cb8d76e17e6273b7643300b17e726',1,'firstLoginToGameLoading():&#160;userInterfaceBeforeGameStarts.c']]],
  ['foodinit_4',['foodInit',['../food_8c.html#a15f45365d9beb689afd35c9c09bfc832',1,'foodInit(GameAllRunningData *data, int number):&#160;food.c'],['../food_8h.html#a15f45365d9beb689afd35c9c09bfc832',1,'foodInit(GameAllRunningData *data, int number):&#160;food.c']]]
];
