var searchData=
[
  ['enable_5fnormal_5finput_0',['enable_normal_input',['../group__OSAdapt.html#ga418b098dfd5fd67e21ea0f6d30c6627e',1,'snakeFullCompat.c']]],
  ['enablenormalinput_1',['enableNormalInput',['../standardIO_8h.html#a12141e910d803598c134f9238d2bff8d',1,'enableNormalInput(const pid_t childProcess):&#160;standardIO.c'],['../standardIO_8c.html#a12141e910d803598c134f9238d2bff8d',1,'enableNormalInput(const pid_t childProcess):&#160;standardIO.c']]],
  ['exitapp_2',['exitApp',['../exitApp_8c.html#a79aad2612531b49d7ccecf4ec555335f',1,'exitApp(int retn, const GameAllRunningData *data):&#160;exitApp.c'],['../exitApp_8h.html#a79aad2612531b49d7ccecf4ec555335f',1,'exitApp(int retn, const GameAllRunningData *data):&#160;exitApp.c']]]
];
