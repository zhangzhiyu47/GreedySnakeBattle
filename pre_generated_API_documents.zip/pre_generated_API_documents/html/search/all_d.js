var searchData=
[
  ['implied_0',['IMPLIED',['../LICENSE_8txt.html#ab0624cdd79a1b72ae3e8cb7b147149da',1,'LICENSE.txt']]],
  ['import_20public_20key_20located_20in_20the_20project_20root_20directory_20_3a_1',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['in_20the_20project_20root_20directory_20_3a_2',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['init_5fterminal_5fsettings_3',['init_terminal_settings',['../group__OSAdapt.html#ga729f169ee94ac6146444e514163e8e86',1,'snakeFullCompat.c']]],
  ['initallgamedata_4',['initAllGameData',['../gameStartupRelated_8c.html#a32bc30565280b8197a1c4e99927b0b66',1,'initAllGameData(GameAllRunningData *data):&#160;gameStartupRelated.c'],['../gameStartupRelated_8h.html#a32bc30565280b8197a1c4e99927b0b66',1,'initAllGameData(GameAllRunningData *data):&#160;gameStartupRelated.c']]],
  ['install_5',['Install',['../index.html#autotoc_md93',1,'']]],
  ['install_20gpg_20strong_6',['&lt;strong&gt;Install GPG&lt;/strong&gt;',['../index.html#autotoc_md60',1,'']]],
  ['install_20uninstall_7',['Install &amp; Uninstall',['../index.html#autotoc_md92',1,'']]],
  ['installation_8',['Build &amp; Installation',['../index.html#autotoc_md89',1,'']]],
  ['installation_20contents_9',['Installation Contents',['../index.html#autotoc_md95',1,'']]],
  ['interface_10',['Interface',['../index.html#autotoc_md81',1,'Game Interface'],['../GSnakeBGEI.html',1,'Greedy Snake Battle Game External Interface']]],
  ['introduction_11',['Introduction',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md5',1,'Introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md19',1,'Introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md29',1,'Introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md43',1,'Introduction']]],
  ['introduction_12',['introduction',['../OffLineMode.html',1,'OffLine mode introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md18',1,'OffLine mode introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md42',1,'OffLine mode introduction']]],
  ['introduction_20to_20the_20snake_20battle_13',['Introduction to the Snake Battle',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md10',1,'Introduction to the Snake Battle'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md34',1,'Introduction to the Snake Battle']]],
  ['isconfigfileopenfail_14',['isConfigFileOpenFail',['../globalVariable_8c.html#aa533fc4d184458e9052b87a69d8e406b',1,'isConfigFileOpenFail:&#160;globalVariable.c'],['../globalVariable_8h.html#aa533fc4d184458e9052b87a69d8e406b',1,'isConfigFileOpenFail:&#160;globalVariable.c']]],
  ['isenableeatslfgmover_15',['isEnableEatSlfGmOver',['../structGameAllRunningData.html#a70a0d1a0bad3b425fc5dc94bd0931c8c',1,'GameAllRunningData::isEnableEatSlfGmOver'],['../structGameConfig.html#afa2491abf3fc1deb31fd86db7498a2f4',1,'GameConfig::isEnableEatSlfGmOver']]],
  ['isenableobs_16',['isEnableObs',['../structGameAllRunningData.html#a416fb5fb0fbeb677bb50fff85841a4d2',1,'GameAllRunningData::isEnableObs'],['../structGameConfig.html#a2ef4b9e991958810e095b355d6b10a55',1,'GameConfig::isEnableObs']]],
  ['issues_17',['Known Issues',['../index.html#autotoc_md99',1,'']]],
  ['isusersnakeeatobssnake_18',['isUserSnakeEatObsSnake',['../userSnake_8h.html#a3351c37ec6e4a50230dbc20d6bde8c92',1,'isUserSnakeEatObsSnake(const GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a3351c37ec6e4a50230dbc20d6bde8c92',1,'isUserSnakeEatObsSnake(const GameAllRunningData *data):&#160;userSnake.c']]],
  ['isusersnakeeatself_19',['isUserSnakeEatSelf',['../userSnake_8h.html#a364a46c3f81e2f0e70d246e87bbbafbc',1,'isUserSnakeEatSelf(const GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a364a46c3f81e2f0e70d246e87bbbafbc',1,'isUserSnakeEatSelf(const GameAllRunningData *data):&#160;userSnake.c']]],
  ['isusersnakeeatwall_20',['isUserSnakeEatWall',['../userSnake_8h.html#a21066831bc671cd2e9e99e43fe404c54',1,'isUserSnakeEatWall(const GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a21066831bc671cd2e9e99e43fe404c54',1,'isUserSnakeEatWall(const GameAllRunningData *data):&#160;userSnake.c']]]
];
