var searchData=
[
  ['header_20file_20and_20function_20prototype_0',['Header file and function prototype',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md2',1,'Header file and function prototype'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md26',1,'Header file and function prototype']]],
  ['high_1',['HIGH',['../globalVariable_8c.html#a06f4596b463eb3c49c5fbaf8d53c6b86',1,'HIGH:&#160;globalVariable.c'],['../globalVariable_8h.html#a06f4596b463eb3c49c5fbaf8d53c6b86',1,'HIGH:&#160;globalVariable.c']]],
  ['histryhighestscr_2',['histryHighestScr',['../structGameAllRunningData.html#a2908ecf7c3357a7bdbb1ad51f57c05fe',1,'GameAllRunningData::histryHighestScr'],['../structGameConfig.html#afdb4ef43e26fee9db874276c03fe7251',1,'GameConfig::histryHighestScr']]]
];
