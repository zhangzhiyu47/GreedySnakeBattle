var searchData=
[
  ['脚本内容_20strong_0',['&lt;strong&gt;1. 脚本内容&lt;/strong&gt;',['../index.html#autotoc_md139',1,'']]],
  ['脚本特点_20strong_1',['&lt;strong&gt;3. 脚本特点&lt;/strong&gt;',['../index.html#autotoc_md141',1,'']]]
];
