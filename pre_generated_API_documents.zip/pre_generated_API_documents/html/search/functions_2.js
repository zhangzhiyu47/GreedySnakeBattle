var searchData=
[
  ['disablenormalinput_0',['disableNormalInput',['../standardIO_8h.html#acb45a1cc0c41157397f5469cf7a5d752',1,'disableNormalInput(const pid_t childProcess):&#160;standardIO.c'],['../standardIO_8c.html#acb45a1cc0c41157397f5469cf7a5d752',1,'disableNormalInput(const pid_t childProcess):&#160;standardIO.c']]]
];
