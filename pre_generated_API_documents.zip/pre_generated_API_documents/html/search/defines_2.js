var searchData=
[
  ['printf_5fcolor_0',['printf_color',['../snakeFullCompat_8h.html#a1bd9abaa54ae9d0d14f10c72374e14e8',1,'snakeFullCompat.h']]]
];
