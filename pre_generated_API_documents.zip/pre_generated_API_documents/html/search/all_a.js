var searchData=
[
  ['enablenormalinput_0',['enableNormalInput',['../standardIO_8h.html#a12141e910d803598c134f9238d2bff8d',1,'enableNormalInput(const pid_t childProcess):&#160;standardIO.c'],['../standardIO_8c.html#a12141e910d803598c134f9238d2bff8d',1,'enableNormalInput(const pid_t childProcess):&#160;standardIO.c']]],
  ['example_20of_20this_20function_1',['Example of this function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md22',1,'Example of this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md46',1,'Example of this function']]],
  ['exitapp_2',['exitApp',['../exitApp_8c.html#a79aad2612531b49d7ccecf4ec555335f',1,'exitApp(int retn, const GameAllRunningData *data):&#160;exitApp.c'],['../exitApp_8h.html#a79aad2612531b49d7ccecf4ec555335f',1,'exitApp(int retn, const GameAllRunningData *data):&#160;exitApp.c']]],
  ['exitapp_2ec_3',['exitApp.c',['../exitApp_8c.html',1,'']]],
  ['exitapp_2eh_4',['exitApp.h',['../exitApp_8h.html',1,'']]],
  ['external_20interface_5',['Greedy Snake Battle Game External Interface',['../GSnakeBGEI.html',1,'']]]
];
