var searchData=
[
  ['use_0',['use',['../LICENSE_8txt.html#ab8202310c90e99c59d9ea1f58f920a91',1,'LICENSE.txt']]],
  ['userinterfacebeforegamestarts_2ec_1',['userInterfaceBeforeGameStarts.c',['../userInterfaceBeforeGameStarts_8c.html',1,'']]],
  ['userinterfacebeforegamestarts_2eh_2',['userInterfaceBeforeGameStarts.h',['../userInterfaceBeforeGameStarts_8h.html',1,'']]],
  ['usersnake_2ec_3',['userSnake.c',['../userSnake_8c.html',1,'']]],
  ['usersnake_2eh_4',['userSnake.h',['../userSnake_8h.html',1,'']]],
  ['usersnakeeatfood_5',['userSnakeEatFood',['../userSnake_8h.html#ad822f76f44eea9149083a0fa823f51ae',1,'userSnakeEatFood(GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#ad822f76f44eea9149083a0fa823f51ae',1,'userSnakeEatFood(GameAllRunningData *data):&#160;userSnake.c']]],
  ['usersnakemove_6',['userSnakeMove',['../userSnake_8h.html#a0ac59372daf37c105ee1df4fc06e7731',1,'userSnakeMove(GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a0ac59372daf37c105ee1df4fc06e7731',1,'userSnakeMove(GameAllRunningData *data):&#160;userSnake.c']]],
  ['usersnakemovedireccontrol_7',['userSnakeMoveDirecControl',['../userSnake_8h.html#aaab8f7612240e173d00b74cf1b7bdd35',1,'userSnakeMoveDirecControl(GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#aaab8f7612240e173d00b74cf1b7bdd35',1,'userSnakeMoveDirecControl(GameAllRunningData *data):&#160;userSnake.c']]],
  ['usrsnkbody_8',['usrSnkBody',['../structGameAllRunningData.html#ad849df05c5275e274dc2035a72298b86',1,'GameAllRunningData']]],
  ['usrsnkgameendstate_9',['usrSnkGameEndState',['../structGameAllRunningData.html#a49344e21253ffac8e1496a1d85c9931c',1,'GameAllRunningData']]],
  ['usrsnkiseatingobssnk_10',['usrSnkIsEatingObsSnk',['../structGameAllRunningData.html#a3ca410f863abb14938ece020b45549df',1,'GameAllRunningData']]],
  ['usrsnkisjumping_11',['usrSnkIsJumping',['../structGameAllRunningData.html#a93f0f7965619c03acd8df91690c33623',1,'GameAllRunningData']]],
  ['usrsnkleng_12',['usrSnkLeng',['../structGameAllRunningData.html#adfedf2bd899089b99f5a69caaa41e0ce',1,'GameAllRunningData']]],
  ['usrsnknxtxdrc_13',['usrSnkNxtXDrc',['../structGameAllRunningData.html#a62bbd5ffebf9dd2f3afb5dbeb7726e8a',1,'GameAllRunningData']]],
  ['usrsnknxtydrc_14',['usrSnkNxtYDrc',['../structGameAllRunningData.html#a8a3fdc16b93c0437e64e84d36053689e',1,'GameAllRunningData']]],
  ['usrsrc_15',['usrSrc',['../structGameAllRunningData.html#af1a0f3e4fcf0e9b80af79bcd10e21445',1,'GameAllRunningData']]]
];
