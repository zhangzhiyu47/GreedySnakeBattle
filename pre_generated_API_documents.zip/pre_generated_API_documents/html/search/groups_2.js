var searchData=
[
  ['game_20settings_0',['Greedy Snake Battle Game Settings',['../group__SetConfig.html',1,'']]],
  ['greedy_20snake_20battle_20game_20settings_1',['Greedy Snake Battle Game Settings',['../group__SetConfig.html',1,'']]]
];
