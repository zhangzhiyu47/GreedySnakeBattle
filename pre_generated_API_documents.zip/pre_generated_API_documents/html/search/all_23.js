var searchData=
[
  ['卸载_0',['卸载',['../index.html#autotoc_md163',1,'卸载'],['../index.html#autotoc_md161',1,'执行Make进行安装/卸载']]]
];
