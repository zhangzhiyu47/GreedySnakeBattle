var searchData=
[
  ['wall_0',['wall',['../structGameAllRunningData.html#a7621a344931807695dfd367c5136dac4',1,'GameAllRunningData']]],
  ['wallnum_1',['wallNum',['../structGameAllRunningData.html#a64eca1b0c8768080e8b90a5f58d36866',1,'GameAllRunningData::wallNum'],['../structGameConfig.html#aba7010ce0ab42593b7ffb35a18f23370',1,'GameConfig::wallNum']]],
  ['wide_2',['WIDE',['../globalVariable_8c.html#ae9c2cc164f7558aa915192e48a4d230e',1,'WIDE:&#160;globalVariable.c'],['../globalVariable_8h.html#ae9c2cc164f7558aa915192e48a4d230e',1,'WIDE:&#160;globalVariable.h']]],
  ['wordcolr_3',['wordColr',['../structGameConfig.html#a08e8265e2c7649d07f39ae0530cd4969',1,'GameConfig']]]
];
