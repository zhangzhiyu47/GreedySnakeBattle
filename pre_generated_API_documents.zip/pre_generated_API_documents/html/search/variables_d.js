var searchData=
[
  ['use_0',['use',['../LICENSE_8txt.html#ab8202310c90e99c59d9ea1f58f920a91',1,'LICENSE.txt']]],
  ['usrsnkbody_1',['usrSnkBody',['../structGameAllRunningData.html#ad849df05c5275e274dc2035a72298b86',1,'GameAllRunningData']]],
  ['usrsnkgameendstate_2',['usrSnkGameEndState',['../structGameAllRunningData.html#a49344e21253ffac8e1496a1d85c9931c',1,'GameAllRunningData']]],
  ['usrsnkiseatingobssnk_3',['usrSnkIsEatingObsSnk',['../structGameAllRunningData.html#a3ca410f863abb14938ece020b45549df',1,'GameAllRunningData']]],
  ['usrsnkisjumping_4',['usrSnkIsJumping',['../structGameAllRunningData.html#a93f0f7965619c03acd8df91690c33623',1,'GameAllRunningData']]],
  ['usrsnkleng_5',['usrSnkLeng',['../structGameAllRunningData.html#adfedf2bd899089b99f5a69caaa41e0ce',1,'GameAllRunningData']]],
  ['usrsnknxtxdrc_6',['usrSnkNxtXDrc',['../structGameAllRunningData.html#a62bbd5ffebf9dd2f3afb5dbeb7726e8a',1,'GameAllRunningData']]],
  ['usrsnknxtydrc_7',['usrSnkNxtYDrc',['../structGameAllRunningData.html#a8a3fdc16b93c0437e64e84d36053689e',1,'GameAllRunningData']]],
  ['usrsrc_8',['usrSrc',['../structGameAllRunningData.html#af1a0f3e4fcf0e9b80af79bcd10e21445',1,'GameAllRunningData']]]
];
