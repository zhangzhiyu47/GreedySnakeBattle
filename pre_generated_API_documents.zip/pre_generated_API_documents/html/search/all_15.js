var searchData=
[
  ['qt_20style_20strong_0',['Qt Style strong',['../index.html#autotoc_md106',1,'&lt;strong&gt;2. Naming Conventions (Qt Style)&lt;/strong&gt;'],['../index.html#autotoc_md110',1,'&lt;strong&gt;3. Code Style (Qt Style)&lt;/strong&gt;']]]
];
