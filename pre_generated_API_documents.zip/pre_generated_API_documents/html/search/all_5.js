var searchData=
[
  ['about_20greedy_20snake_20battle_20game_0',['About Greedy Snake Battle Game',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md9',1,'About Greedy Snake Battle Game'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md33',1,'About Greedy Snake Battle Game']]],
  ['about_20this_20function_1',['About this function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md1',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md25',1,'About this function']]],
  ['adaptation_20function_20group_2',['Operating system adaptation function group',['../group__OSAdapt.html',1,'']]],
  ['and_20frame_3',['and frame',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md11',1,'Game running process and frame'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md35',1,'Game running process and frame']]],
  ['and_20function_20prototype_4',['and function prototype',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md2',1,'Header file and function prototype'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md26',1,'Header file and function prototype']]],
  ['and_20todos_5',['and TODOs',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md14',1,'BUGs and TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md38',1,'BUGs and TODOs']]],
  ['attention_6',['Attention',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md20',1,'Attention'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md44',1,'Attention']]],
  ['authorization_20scope_7',['Authorization Scope',['../index.html#autotoc_md53',1,'']]],
  ['automated_20verification_20scripts_8',['Automated Verification Scripts',['../index.html#autotoc_md67',1,'']]]
];
