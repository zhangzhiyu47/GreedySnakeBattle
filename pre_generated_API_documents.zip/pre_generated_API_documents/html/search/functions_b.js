var searchData=
[
  ['restore_5fterminal_5fsettings_0',['restore_terminal_settings',['../group__OSAdapt.html#gae1417bdb53e4bf41cb65ed3a25f2e255',1,'snakeFullCompat.c']]]
];
