var searchData=
[
  ['external_20interface_0',['Greedy Snake Battle Game External Interface',['../GSnakeBGEI.html',1,'']]]
];
