var searchData=
[
  ['liability_0',['LIABILITY',['../LICENSE_8txt.html#a154c0f6f925190567752588d1ff5458f',1,'LICENSE.txt']]],
  ['library_1',['Library',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md3',1,'Library'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md27',1,'Library']]],
  ['license_2',['License',['../LICENSE_8txt.html#aeba0e8be08e24cc3a8c4f3b719ef3d30',1,'LICENSE.txt']]],
  ['license_2etxt_3',['LICENSE.txt',['../LICENSE_8txt.html',1,'']]],
  ['linux_20macos_4',['Linux/MacOS',['../index.html#autotoc_md76',1,'']]],
  ['linux_20macos_20strong_5',['&lt;strong&gt;Linux/MacOS&lt;/strong&gt;',['../index.html#autotoc_md69',1,'']]],
  ['linuxkbhit_6',['linuxKbhit',['../standardIO_8h.html#adbee67c298d66779a11a599e515558d4',1,'linuxKbhit():&#160;standardIO.c'],['../standardIO_8c.html#adbee67c298d66779a11a599e515558d4',1,'linuxKbhit():&#160;standardIO.c']]],
  ['list_7',['List',['../bug.html',1,'Bug List'],['../todo.html',1,'Todo List']]]
];
