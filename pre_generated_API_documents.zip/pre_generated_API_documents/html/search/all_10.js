var searchData=
[
  ['liability_0',['LIABILITY',['../LICENSE_8txt.html#a154c0f6f925190567752588d1ff5458f',1,'LICENSE.txt']]],
  ['library_1',['Library',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md3',1,'Library'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md27',1,'Library']]],
  ['license_2',['License',['../LICENSE_8txt.html#aeba0e8be08e24cc3a8c4f3b719ef3d30',1,'License():&#160;LICENSE.txt'],['../index.html#autotoc_md52',1,'MIT License'],['../index.html#autotoc_md51',1,'Project License'],['../index.html#autotoc_md56',1,'View License']]],
  ['license_2etxt_3',['LICENSE.txt',['../LICENSE_8txt.html',1,'']]],
  ['linking_20options_4',['Linking Options',['../index.html#autotoc_md82',1,'']]],
  ['linux_20macos_5',['Linux macOS',['../index.html#autotoc_md69',1,'Linux/macOS'],['../index.html#autotoc_md138',1,'Linux/macOS']]],
  ['linux_20macos_20strong_6',['Linux macOS strong',['../index.html#autotoc_md62',1,'&lt;strong&gt;Linux/macOS&lt;/strong&gt;'],['../index.html#autotoc_md131',1,'&lt;strong&gt;Linux/macOS&lt;/strong&gt;']]],
  ['linux_5fgetch_7',['linux_getch',['../group__OSAdapt.html#ga21991acf1aba6035909461c9e7ff90e2',1,'snakeFullCompat.h']]],
  ['linux_5fkbhit_8',['linux_kbhit',['../group__OSAdapt.html#gafdd3512fd59d76568fd077086e3895d2',1,'snakeFullCompat.h']]],
  ['list_9',['List',['../bug.html',1,'Bug List'],['../todo.html',1,'Todo List']]],
  ['located_20in_20the_20project_20root_20directory_20_3a_10',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]]
];
