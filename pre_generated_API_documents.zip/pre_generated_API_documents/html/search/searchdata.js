var indexSectionsWithContent =
{
  0: "123:_abcdefghijklmnopqrstuvwxy​代位使函卸参命如安导已总执未构查注游目离签脚自规解贡贪跨返连项预风验：",
  1: "gp",
  2: "efglmoprstuw",
  3: "_bcdefgilmorstuw",
  4: "_cdfhiklmoprsuwxy",
  5: "gmp",
  6: "chps",
  7: "abcfgos",
  8: "begilmost"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

