var indexSectionsWithContent =
{
  0: "123456abcdefghiklmoprstuwxy​下代位使函卸参启命基如安导已总执未构查注游环目离签脚自规解贡贪跨返连选项预风验：",
  1: "gp",
  2: "efglmoprstuw",
  3: "bcdefgilmorstuw",
  4: "cdfhiklmoprsuwxy",
  5: "gmp",
  6: "bcgs",
  7: "begilmost贪"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Modules",
  7: "Pages"
};

