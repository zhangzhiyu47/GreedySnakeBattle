var searchData=
[
  ['执行make进行安装_20卸载_0',['执行Make进行安装/卸载',['../index.html#autotoc_md161',1,'']]]
];
