var searchData=
[
  ['food_0',['food',['../structGameAllRunningData.html#a28ad2ecad88da0d425f2ec2cede034f6',1,'GameAllRunningData']]],
  ['foodnum_1',['foodNum',['../structGameAllRunningData.html#abb8cb398b68ca2533dc09dd1bc10d907',1,'GameAllRunningData::foodNum'],['../structGameConfig.html#a62c3ddd92cf23e30619f0e737e499e74',1,'GameConfig::foodNum']]],
  ['from_2',['FROM',['../LICENSE_8txt.html#ac44d0f7742875ad0d1fc3a6de1ee0f7d',1,'LICENSE.txt']]]
];
