var searchData=
[
  ['battle_20game_20settings_0',['Greedy Snake Battle Game Settings',['../group__SetConfig.html',1,'']]]
];
