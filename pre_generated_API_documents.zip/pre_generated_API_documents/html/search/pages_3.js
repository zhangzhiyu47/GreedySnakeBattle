var searchData=
[
  ['interface_0',['Greedy Snake Battle Game External Interface',['../GSnakeBGEI.html',1,'']]],
  ['introduction_1',['OffLine mode introduction',['../OffLineMode.html',1,'']]]
];
