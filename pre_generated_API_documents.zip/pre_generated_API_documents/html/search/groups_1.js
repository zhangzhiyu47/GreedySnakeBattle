var searchData=
[
  ['capture_0',['Signal capture',['../group__SignalCapture.html',1,'']]]
];
