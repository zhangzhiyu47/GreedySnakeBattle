var searchData=
[
  ['painting_2ec_0',['painting.c',['../painting_8c.html',1,'']]],
  ['painting_2eh_1',['painting.h',['../painting_8h.html',1,'']]],
  ['parameter_2',['Parameter',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md6',1,'Parameter'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md30',1,'Parameter']]],
  ['parameters_3',['Parameters',['../index.html#autotoc_md84',1,'']]],
  ['plans_4',['Future Plans',['../index.html#autotoc_md100',1,'']]],
  ['platform_20support_5',['Cross-Platform Support',['../index.html#autotoc_md97',1,'']]],
  ['point_6',['Point',['../structPoint.html',1,'Point'],['../Point_8h.html#a332e649c40b7d806629d2cfa046f3ee0',1,'Point:&#160;Point.h']]],
  ['point_2eh_7',['Point.h',['../Point_8h.html',1,'']]],
  ['possible_20future_20functions_8',['Possible future functions',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md12',1,'Possible future functions'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md36',1,'Possible future functions']]],
  ['prerequisites_9',['Prerequisites',['../index.html#autotoc_md59',1,'']]],
  ['printf_5fcolor_10',['printf_color',['../snakeFullCompat_8h.html#a1bd9abaa54ae9d0d14f10c72374e14e8',1,'snakeFullCompat.h']]],
  ['process_20and_20frame_11',['process and frame',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md11',1,'Game running process and frame'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md35',1,'Game running process and frame']]],
  ['project_20license_12',['Project License',['../index.html#autotoc_md51',1,'']]],
  ['project_20overview_13',['Project Overview',['../index.html#autotoc_md50',1,'']]],
  ['project_20root_20directory_20_3a_14',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['prototype_15',['Function Prototype',['../index.html#autotoc_md83',1,'']]],
  ['prototype_16',['prototype',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md2',1,'Header file and function prototype'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md26',1,'Header file and function prototype']]],
  ['public_20key_20located_20in_20the_20project_20root_20directory_20_3a_17',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['publish_18',['publish',['../LICENSE_8txt.html#ae6b6c4d3ae1a4140d31294e27bb0ebd8',1,'LICENSE.txt']]]
];
