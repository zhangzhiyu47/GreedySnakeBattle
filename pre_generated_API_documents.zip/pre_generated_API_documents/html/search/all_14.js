var searchData=
[
  ['readme_2emd_0',['README.md',['../README_8md.html',1,'']]],
  ['restoreterminalsettings_1',['restoreTerminalSettings',['../terminal_8h.html#aa0e5be3a02379220f3ce32873a36c5d0',1,'restoreTerminalSettings():&#160;terminal.c'],['../terminal_8c.html#aa0e5be3a02379220f3ce32873a36c5d0',1,'restoreTerminalSettings():&#160;terminal.c']]],
  ['restriction_2',['restriction',['../LICENSE_8txt.html#ac0e1e4a858a6a19c5392f7f6d29f969c',1,'LICENSE.txt']]],
  ['return_3',['Return',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md7',1,'Return'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md31',1,'Return']]],
  ['running_20process_20and_20frame_4',['running process and frame',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md11',1,'Game running process and frame'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md35',1,'Game running process and frame']]]
];
