var searchData=
[
  ['fatherprocesscatchchld_0',['fatherProcessCatchCHLD',['../group__SignalCapture.html#ga2754d2b299b7c121010e7c813f7d14c3',1,'fatherProcessCatchCHLD(int signum):&#160;signalCapture.c'],['../group__SignalCapture.html#ga2754d2b299b7c121010e7c813f7d14c3',1,'fatherProcessCatchCHLD(int signum):&#160;signalCapture.c']]],
  ['fatherprocesscatchint_1',['fatherProcessCatchINT',['../group__SignalCapture.html#ga8f0231b3b157dd242bb7cf83f66ae6a2',1,'fatherProcessCatchINT(int signum):&#160;signalCapture.c'],['../group__SignalCapture.html#ga8f0231b3b157dd242bb7cf83f66ae6a2',1,'fatherProcessCatchINT(int signum):&#160;signalCapture.c']]],
  ['file_20and_20function_20prototype_2',['file and function prototype',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md2',1,'Header file and function prototype'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md26',1,'Header file and function prototype']]],
  ['files_3',['files',['../LICENSE_8txt.html#a953a9e6174b7f8cab75d34ed6ae02c98',1,'LICENSE.txt']]],
  ['firstlogintogameloading_4',['firstLoginToGameLoading',['../userInterfaceBeforeGameStarts_8h.html#afb3cb8d76e17e6273b7643300b17e726',1,'firstLoginToGameLoading():&#160;userInterfaceBeforeGameStarts.c'],['../userInterfaceBeforeGameStarts_8c.html#afb3cb8d76e17e6273b7643300b17e726',1,'firstLoginToGameLoading():&#160;userInterfaceBeforeGameStarts.c']]],
  ['food_5',['food',['../structGameAllRunningData.html#a28ad2ecad88da0d425f2ec2cede034f6',1,'GameAllRunningData']]],
  ['food_2ec_6',['food.c',['../food_8c.html',1,'']]],
  ['food_2eh_7',['food.h',['../food_8h.html',1,'']]],
  ['foodinit_8',['foodInit',['../food_8c.html#a15f45365d9beb689afd35c9c09bfc832',1,'foodInit(GameAllRunningData *data, int number):&#160;food.c'],['../food_8h.html#a15f45365d9beb689afd35c9c09bfc832',1,'foodInit(GameAllRunningData *data, int number):&#160;food.c']]],
  ['foodnum_9',['foodNum',['../structGameAllRunningData.html#abb8cb398b68ca2533dc09dd1bc10d907',1,'GameAllRunningData::foodNum'],['../structGameConfig.html#a62c3ddd92cf23e30619f0e737e499e74',1,'GameConfig::foodNum']]],
  ['frame_10',['frame',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md11',1,'Game running process and frame'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md35',1,'Game running process and frame']]],
  ['from_11',['FROM',['../LICENSE_8txt.html#ac44d0f7742875ad0d1fc3a6de1ee0f7d',1,'LICENSE.txt']]],
  ['function_12',['Function',['../GSnakeBGEI.html#autotoc_md23',1,'']]],
  ['function_13',['function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md1',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md25',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md22',1,'Example of this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md46',1,'Example of this function']]],
  ['function_20prototype_14',['function prototype',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md2',1,'Header file and function prototype'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md26',1,'Header file and function prototype']]],
  ['functions_15',['functions',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md12',1,'Possible future functions'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md36',1,'Possible future functions']]],
  ['future_20functions_16',['future functions',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md12',1,'Possible future functions'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md36',1,'Possible future functions']]]
];
