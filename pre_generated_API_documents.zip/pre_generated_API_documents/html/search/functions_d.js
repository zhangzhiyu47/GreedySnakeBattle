var searchData=
[
  ['usersnakeeatfood_0',['userSnakeEatFood',['../userSnake_8h.html#ad822f76f44eea9149083a0fa823f51ae',1,'userSnakeEatFood(GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#ad822f76f44eea9149083a0fa823f51ae',1,'userSnakeEatFood(GameAllRunningData *data):&#160;userSnake.c']]],
  ['usersnakemove_1',['userSnakeMove',['../userSnake_8h.html#a0ac59372daf37c105ee1df4fc06e7731',1,'userSnakeMove(GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#a0ac59372daf37c105ee1df4fc06e7731',1,'userSnakeMove(GameAllRunningData *data):&#160;userSnake.c']]],
  ['usersnakemovedireccontrol_2',['userSnakeMoveDirecControl',['../userSnake_8h.html#aaab8f7612240e173d00b74cf1b7bdd35',1,'userSnakeMoveDirecControl(GameAllRunningData *data):&#160;userSnake.c'],['../userSnake_8c.html#aaab8f7612240e173d00b74cf1b7bdd35',1,'userSnakeMoveDirecControl(GameAllRunningData *data):&#160;userSnake.c']]]
];
