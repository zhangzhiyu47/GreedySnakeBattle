var searchData=
[
  ['terminal256colortablepainting_0',['terminal256ColorTablePainting',['../terminal_8h.html#a82d95d54b00e96ca63c3dd5fa8d72b07',1,'terminal256ColorTablePainting(const GameConfig *config):&#160;terminal.c'],['../terminal_8c.html#a82d95d54b00e96ca63c3dd5fa8d72b07',1,'terminal256ColorTablePainting(const GameConfig *config):&#160;terminal.c']]],
  ['terminalsize_1',['terminalSize',['../terminal_8h.html#a1ee99b95286c20f059d063e24bc01c8a',1,'terminalSize():&#160;terminal.c'],['../terminal_8c.html#a1ee99b95286c20f059d063e24bc01c8a',1,'terminalSize():&#160;terminal.c']]]
];
