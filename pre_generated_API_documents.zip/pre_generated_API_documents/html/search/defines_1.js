var searchData=
[
  ['hide_5fcursor_0',['HIDE_CURSOR',['../snakeFullCompat_8h.html#afda389c3c8b482e025dc765d250a5a0d',1,'snakeFullCompat.h']]]
];
