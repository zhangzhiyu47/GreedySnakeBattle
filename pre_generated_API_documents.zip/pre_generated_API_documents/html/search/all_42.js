var searchData=
[
  ['验证安装_0',['4. 验证安装',['../index.html#autotoc_md89',1,'']]],
  ['验证签名：_1',['3.验证签名：',['../index.html#autotoc_md72',1,'']]]
];
