var searchData=
[
  ['restoreterminalsettings_0',['restoreTerminalSettings',['../terminal_8h.html#aa0e5be3a02379220f3ce32873a36c5d0',1,'restoreTerminalSettings():&#160;terminal.c'],['../terminal_8c.html#aa0e5be3a02379220f3ce32873a36c5d0',1,'restoreTerminalSettings():&#160;terminal.c']]]
];
