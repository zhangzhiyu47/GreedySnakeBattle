var searchData=
[
  ['wallinit_0',['wallInit',['../wall_8h.html#ab50a0bed8c04ecce31c74e09f4470340',1,'wallInit(GameAllRunningData *data):&#160;wall.c'],['../wall_8c.html#ab50a0bed8c04ecce31c74e09f4470340',1,'wallInit(GameAllRunningData *data):&#160;wall.c']]],
  ['wallpainting_1',['wallPainting',['../painting_8h.html#a4d2edc62cd23a0493afac3f787adcbd2',1,'wallPainting(GameAllRunningData *data):&#160;painting.c'],['../painting_8c.html#a4d2edc62cd23a0493afac3f787adcbd2',1,'wallPainting(GameAllRunningData *data):&#160;painting.c']]]
];
