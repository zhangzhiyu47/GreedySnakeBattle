var searchData=
[
  ['readme_2emd_0',['README.md',['../README_8md.html',1,'']]],
  ['requirements_1',['Build Requirements',['../index.html#autotoc_md90',1,'']]],
  ['restore_5fterminal_5fsettings_2',['restore_terminal_settings',['../group__OSAdapt.html#gae1417bdb53e4bf41cb65ed3a25f2e255',1,'snakeFullCompat.c']]],
  ['restriction_3',['restriction',['../LICENSE_8txt.html#ac0e1e4a858a6a19c5392f7f6d29f969c',1,'LICENSE.txt']]],
  ['return_4',['Return',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md7',1,'Return'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md31',1,'Return']]],
  ['return_20values_5',['Return Values',['../index.html#autotoc_md85',1,'']]],
  ['root_20directory_20_3a_6',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['rules_20for_20contributors_20strong_7',['&lt;strong&gt;Summary: Rules for Contributors&lt;/strong&gt;',['../index.html#autotoc_md114',1,'']]],
  ['rules_20strong_20_3a_8',['Rules strong :',['../index.html#autotoc_md103',1,'&lt;strong&gt;Rules&lt;/strong&gt;:'],['../index.html#autotoc_md107',1,'&lt;strong&gt;Rules&lt;/strong&gt;:'],['../index.html#autotoc_md111',1,'&lt;strong&gt;Rules&lt;/strong&gt;:']]],
  ['running_20process_20and_20frame_9',['running process and frame',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md11',1,'Game running process and frame'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md35',1,'Game running process and frame']]]
];
