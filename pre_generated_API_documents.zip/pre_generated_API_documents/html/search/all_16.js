var searchData=
[
  ['terminal_2ec_0',['terminal.c',['../terminal_8c.html',1,'']]],
  ['terminal_2eh_1',['terminal.h',['../terminal_8h.html',1,'']]],
  ['terminal256colortablepainting_2',['terminal256ColorTablePainting',['../terminal_8h.html#a82d95d54b00e96ca63c3dd5fa8d72b07',1,'terminal256ColorTablePainting(const GameConfig *config):&#160;terminal.c'],['../terminal_8c.html#a82d95d54b00e96ca63c3dd5fa8d72b07',1,'terminal256ColorTablePainting(const GameConfig *config):&#160;terminal.c']]],
  ['terminalsize_3',['terminalSize',['../terminal_8h.html#a1ee99b95286c20f059d063e24bc01c8a',1,'terminalSize():&#160;terminal.c'],['../terminal_8c.html#a1ee99b95286c20f059d063e24bc01c8a',1,'terminalSize():&#160;terminal.c']]],
  ['the_20snake_20battle_4',['the Snake Battle',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md10',1,'Introduction to the Snake Battle'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md34',1,'Introduction to the Snake Battle']]],
  ['this_20function_5',['this function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md1',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md25',1,'About this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md22',1,'Example of this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md46',1,'Example of this function']]],
  ['to_20the_20snake_20battle_6',['to the Snake Battle',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md10',1,'Introduction to the Snake Battle'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md34',1,'Introduction to the Snake Battle']]],
  ['todo_20list_7',['Todo List',['../todo.html',1,'']]],
  ['todos_8',['TODOs',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md14',1,'BUGs and TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md38',1,'BUGs and TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md16',1,'TODOs'],['../todo.html#_todo000002',1,'TODOs'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md40',1,'TODOs'],['../todo.html#_todo000006',1,'TODOs']]],
  ['trulydisablenormalinput_9',['trulyDisableNormalInput',['../standardIO_8h.html#a32a50d608e7a5ff0411f1599ca910439',1,'trulyDisableNormalInput():&#160;standardIO.c'],['../standardIO_8c.html#a32a50d608e7a5ff0411f1599ca910439',1,'trulyDisableNormalInput():&#160;standardIO.c']]],
  ['trulyenablenormalinput_10',['trulyEnableNormalInput',['../standardIO_8h.html#ae8443c2d55b54a7d02ebac7d4837fb95',1,'trulyEnableNormalInput():&#160;standardIO.c'],['../standardIO_8c.html#ae8443c2d55b54a7d02ebac7d4837fb95',1,'trulyEnableNormalInput():&#160;standardIO.c']]],
  ['typedef_2eh_11',['typedef.h',['../typedef_8h.html',1,'']]]
];
