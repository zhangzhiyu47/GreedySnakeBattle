var searchData=
[
  ['elements_0',['Game Elements',['../index.html#autotoc_md76',1,'']]],
  ['enable_5fnormal_5finput_1',['enable_normal_input',['../group__OSAdapt.html#ga418b098dfd5fd67e21ea0f6d30c6627e',1,'snakeFullCompat.c']]],
  ['enablenormalinput_2',['enableNormalInput',['../standardIO_8h.html#a12141e910d803598c134f9238d2bff8d',1,'enableNormalInput(const pid_t childProcess):&#160;standardIO.c'],['../standardIO_8c.html#a12141e910d803598c134f9238d2bff8d',1,'enableNormalInput(const pid_t childProcess):&#160;standardIO.c']]],
  ['example_3',['Example',['../index.html#autotoc_md86',1,'']]],
  ['example_20of_20this_20function_4',['Example of this function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md22',1,'Example of this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md46',1,'Example of this function']]],
  ['exitapp_5',['exitApp',['../exitApp_8c.html#a79aad2612531b49d7ccecf4ec555335f',1,'exitApp(int retn, const GameAllRunningData *data):&#160;exitApp.c'],['../exitApp_8h.html#a79aad2612531b49d7ccecf4ec555335f',1,'exitApp(int retn, const GameAllRunningData *data):&#160;exitApp.c']]],
  ['exitapp_2ec_6',['exitApp.c',['../exitApp_8c.html',1,'']]],
  ['exitapp_2eh_7',['exitApp.h',['../exitApp_8h.html',1,'']]],
  ['external_20interface_8',['Greedy Snake Battle Game External Interface',['../GSnakeBGEI.html',1,'']]],
  ['extracting_20the_20signature_20files_9',['1. Extracting the Signature Files',['../index.html#autotoc_md63',1,'']]]
];
