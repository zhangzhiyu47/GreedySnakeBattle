var searchData=
[
  ['naming_20conventions_20qt_20style_20strong_0',['&lt;strong&gt;2. Naming Conventions (Qt Style)&lt;/strong&gt;',['../index.html#autotoc_md106',1,'']]],
  ['notes_20strong_20_3a_1',['Notes strong :',['../index.html#autotoc_md104',1,'&lt;strong&gt;Contributor Notes&lt;/strong&gt;:'],['../index.html#autotoc_md108',1,'&lt;strong&gt;Contributor Notes&lt;/strong&gt;:'],['../index.html#autotoc_md112',1,'&lt;strong&gt;Contributor Notes&lt;/strong&gt;:']]]
];
