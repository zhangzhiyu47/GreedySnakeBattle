var searchData=
[
  ['obsclosestfood_0',['obsClosestFood',['../structGameAllRunningData.html#ac41407256d869f2fae1ff4fcb45e35c9',1,'GameAllRunningData']]],
  ['obseatfood_1',['obsEatFood',['../obstacleSnake_8h.html#ab738497e815437794b5de1faf4aa80a4',1,'obsEatFood(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#ab738497e815437794b5de1faf4aa80a4',1,'obsEatFood(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obseatwallsorusersnake_2',['obsEatWallsOrUserSnake',['../obstacleSnake_8h.html#af6d4e56c0a4a642c5e5b448e56072cdc',1,'obsEatWallsOrUserSnake(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#af6d4e56c0a4a642c5e5b448e56072cdc',1,'obsEatWallsOrUserSnake(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obsinit_3',['obsInit',['../obstacleSnake_8h.html#a2f6e40a7612f2d0b2c0430dfba37d35c',1,'obsInit(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#a2f6e40a7612f2d0b2c0430dfba37d35c',1,'obsInit(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obsmove_4',['obsMove',['../obstacleSnake_8h.html#af424fa8d10d40ea4a01a6181e26aa507',1,'obsMove(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#af424fa8d10d40ea4a01a6181e26aa507',1,'obsMove(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obsmovedireccontrol_5',['obsMoveDirecControl',['../obstacleSnake_8h.html#abb235c1728c395dbc41f3fb85894aa3e',1,'obsMoveDirecControl(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#abb235c1728c395dbc41f3fb85894aa3e',1,'obsMoveDirecControl(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obssnkbody_6',['obsSnkBody',['../structGameAllRunningData.html#a5581e89a990dbe4e49d850f59aa45d6d',1,'GameAllRunningData']]],
  ['obssnkleng_7',['obsSnkLeng',['../structGameAllRunningData.html#ad518195cd557b7d47876c17e53fe5883',1,'GameAllRunningData']]],
  ['obssnknxtxdrc_8',['obsSnkNxtXDrc',['../structGameAllRunningData.html#abe1d920c98dd00b5c98dfb8e8a2fb18e',1,'GameAllRunningData']]],
  ['obssnknxtydrc_9',['obsSnkNxtYDrc',['../structGameAllRunningData.html#ab56d03129caa85ebe087d35eced272db',1,'GameAllRunningData']]],
  ['obsstate_10',['obsState',['../structGameAllRunningData.html#a35f0a19fe856f913e0a400ac22f4d820',1,'GameAllRunningData']]],
  ['obstaclesnake_2ec_11',['obstacleSnake.c',['../obstacleSnake_8c.html',1,'']]],
  ['obstaclesnake_2eh_12',['obstacleSnake.h',['../obstacleSnake_8h.html',1,'']]],
  ['of_20this_20function_13',['of this function',['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md22',1,'Example of this function'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md46',1,'Example of this function']]],
  ['offline_20mode_20introduction_14',['OffLine mode introduction',['../OffLineMode.html',1,'OffLine mode introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md18',1,'OffLine mode introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md42',1,'OffLine mode introduction']]],
  ['offlinemodeintroduction_2ec_15',['OfflineModeIntroduction.c',['../OfflineModeIntroduction_8c.html',1,'']]],
  ['originaltermios_16',['originalTermios',['../globalVariable_8c.html#ac202057a8bed4e3c46bd968ad096a491',1,'originalTermios:&#160;globalVariable.c'],['../globalVariable_8h.html#ac202057a8bed4e3c46bd968ad096a491',1,'originalTermios:&#160;globalVariable.c']]],
  ['otherwise_17',['OTHERWISE',['../LICENSE_8txt.html#ae4c7c54aef6c135b4520f2237dbcf7c6',1,'LICENSE.txt']]],
  ['outlinemodeconfig_18',['outlineModeConfig',['../globalVariable_8c.html#ad4cf03814d1b578be01dc7eda1996347',1,'outlineModeConfig:&#160;globalVariable.c'],['../globalVariable_8h.html#ad4cf03814d1b578be01dc7eda1996347',1,'outlineModeConfig:&#160;globalVariable.c']]]
];
