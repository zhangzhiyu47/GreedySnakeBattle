var searchData=
[
  ['obseatfood_0',['obsEatFood',['../obstacleSnake_8h.html#ab738497e815437794b5de1faf4aa80a4',1,'obsEatFood(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#ab738497e815437794b5de1faf4aa80a4',1,'obsEatFood(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obseatwallsorusersnake_1',['obsEatWallsOrUserSnake',['../obstacleSnake_8h.html#af6d4e56c0a4a642c5e5b448e56072cdc',1,'obsEatWallsOrUserSnake(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#af6d4e56c0a4a642c5e5b448e56072cdc',1,'obsEatWallsOrUserSnake(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obsinit_2',['obsInit',['../obstacleSnake_8h.html#a2f6e40a7612f2d0b2c0430dfba37d35c',1,'obsInit(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#a2f6e40a7612f2d0b2c0430dfba37d35c',1,'obsInit(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obsmove_3',['obsMove',['../obstacleSnake_8h.html#af424fa8d10d40ea4a01a6181e26aa507',1,'obsMove(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#af424fa8d10d40ea4a01a6181e26aa507',1,'obsMove(GameAllRunningData *data):&#160;obstacleSnake.c']]],
  ['obsmovedireccontrol_4',['obsMoveDirecControl',['../obstacleSnake_8h.html#abb235c1728c395dbc41f3fb85894aa3e',1,'obsMoveDirecControl(GameAllRunningData *data):&#160;obstacleSnake.c'],['../obstacleSnake_8c.html#abb235c1728c395dbc41f3fb85894aa3e',1,'obsMoveDirecControl(GameAllRunningData *data):&#160;obstacleSnake.c']]]
];
