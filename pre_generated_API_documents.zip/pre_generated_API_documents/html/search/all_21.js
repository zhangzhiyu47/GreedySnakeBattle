var searchData=
[
  ['卸载_0',['卸载',['../index.html#autotoc_md107',1,'卸载'],['../index.html#autotoc_md105',1,'执行Make进行安装/卸载']]]
];
