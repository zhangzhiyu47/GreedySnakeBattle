var searchData=
[
  ['gameallrunningdata_0',['GameAllRunningData',['../structGameAllRunningData.html',1,'']]],
  ['gameconfig_1',['GameConfig',['../structGameConfig.html',1,'']]]
];
