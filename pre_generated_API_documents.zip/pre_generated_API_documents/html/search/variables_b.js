var searchData=
[
  ['scrncolr_0',['scrnColr',['../structGameConfig.html#ac6d83e798f37711a95454c5eeb3d83cd',1,'GameConfig']]],
  ['scrnhigh_1',['scrnHigh',['../structGameConfig.html#a32c199cbbba0cf568746c954fabaf567',1,'GameConfig']]],
  ['scrnwide_2',['scrnWide',['../structGameConfig.html#a85527a5d6bfaa890671ba9fea543fe0f',1,'GameConfig']]],
  ['snake_5fblock_3',['SNAKE_BLOCK',['../GreedySnakeBattleGameExternalInterface_8c.html#a03050ce9ad8ec52058e545c054cf9eae',1,'SNAKE_BLOCK:&#160;GreedySnakeBattleGameExternalInterface.c'],['../GreedySnakeBattleGameExternalInterface_8h.html#a03050ce9ad8ec52058e545c054cf9eae',1,'SNAKE_BLOCK:&#160;GreedySnakeBattleGameExternalInterface.c']]],
  ['snake_5funblock_4',['SNAKE_UNBLOCK',['../GreedySnakeBattleGameExternalInterface_8c.html#a45708c80aae47f2c7a0fd116ef51efcf',1,'SNAKE_UNBLOCK:&#160;GreedySnakeBattleGameExternalInterface.c'],['../GreedySnakeBattleGameExternalInterface_8h.html#a45708c80aae47f2c7a0fd116ef51efcf',1,'SNAKE_UNBLOCK:&#160;GreedySnakeBattleGameExternalInterface.c']]],
  ['so_5',['so',['../LICENSE_8txt.html#ab05c0f0392781fce452b91e1ede41d90',1,'LICENSE.txt']]],
  ['software_6',['Software',['../LICENSE_8txt.html#a22a1529885b3e9d66b0c72fe604fc3dc',1,'LICENSE.txt']]],
  ['speed_7',['speed',['../structGameAllRunningData.html#a1ef29fc3e880901b3828e335cc23dba7',1,'GameAllRunningData::speed'],['../structGameConfig.html#a7b2a685507a316b03d7e44d138032e95',1,'GameConfig::speed']]],
  ['sublicense_8',['sublicense',['../LICENSE_8txt.html#af9fad5470a0b4e968d19b11b7c643fdb',1,'LICENSE.txt']]]
];
