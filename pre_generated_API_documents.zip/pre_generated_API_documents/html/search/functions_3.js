var searchData=
[
  ['disable_5fnormal_5finput_0',['disable_normal_input',['../group__OSAdapt.html#gab24964fdbf0163fd68b7cfde981d0e31',1,'snakeFullCompat.c']]],
  ['disablenormalinput_1',['disableNormalInput',['../standardIO_8h.html#acb45a1cc0c41157397f5469cf7a5d752',1,'disableNormalInput(const pid_t childProcess):&#160;standardIO.c'],['../standardIO_8c.html#acb45a1cc0c41157397f5469cf7a5d752',1,'disableNormalInput(const pid_t childProcess):&#160;standardIO.c']]]
];
