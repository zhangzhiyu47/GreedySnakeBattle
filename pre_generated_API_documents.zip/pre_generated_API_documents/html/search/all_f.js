var searchData=
[
  ['kind_0',['KIND',['../LICENSE_8txt.html#a8e1a82be600178fe97c0e1339897c260',1,'LICENSE.txt']]]
];
