var searchData=
[
  ['key_20located_20in_20the_20project_20root_20directory_20_3a_0',['2. Import Public Key (located in the project root directory):',['../index.html#autotoc_md64',1,'']]],
  ['kind_1',['KIND',['../LICENSE_8txt.html#a8e1a82be600178fe97c0e1339897c260',1,'LICENSE.txt']]],
  ['known_20issues_2',['Known Issues',['../index.html#autotoc_md99',1,'']]]
];
