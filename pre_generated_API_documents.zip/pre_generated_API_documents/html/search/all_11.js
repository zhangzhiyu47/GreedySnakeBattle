var searchData=
[
  ['macos_0',['Linux/MacOS',['../index.html#autotoc_md76',1,'']]],
  ['macos_20strong_1',['&lt;strong&gt;Linux/MacOS&lt;/strong&gt;',['../index.html#autotoc_md69',1,'']]],
  ['main_2',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['main_2ec_3',['main.c',['../main_8c.html',1,'']]],
  ['mainloopofgameprocess_4',['mainLoopOfGameProcess',['../gameMainLogic_8c.html#aaf4584cd0bfe05c944d0b876d33574d3',1,'mainLoopOfGameProcess(GameAllRunningData *data):&#160;gameMainLogic.c'],['../gameMainLogic_8h.html#aaf4584cd0bfe05c944d0b876d33574d3',1,'mainLoopOfGameProcess(GameAllRunningData *data):&#160;gameMainLogic.c']]],
  ['merchantability_5',['MERCHANTABILITY',['../LICENSE_8txt.html#a82e4fcb28d3925b81ac5f50e2b22c270',1,'LICENSE.txt']]],
  ['merge_6',['merge',['../LICENSE_8txt.html#a7653d3ec339e97ccc64ec4f74e440441',1,'LICENSE.txt']]],
  ['minscropnvctrypnt_7',['minScrOpnVctryPnt',['../structGameAllRunningData.html#aabc5256cac299889271ed7df850a4616',1,'GameAllRunningData::minScrOpnVctryPnt'],['../structGameConfig.html#a70d4af3105558c8193064f581dbb7d86',1,'GameConfig::minScrOpnVctryPnt']]],
  ['mit许可证_8',['MIT许可证',['../index.html#autotoc_md52',1,'']]],
  ['mode_20introduction_9',['mode introduction',['../OffLineMode.html',1,'OffLine mode introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md18',1,'OffLine mode introduction'],['../GreedySnakeBattleGameExternalInterface_8h.html#autotoc_md42',1,'OffLine mode introduction']]],
  ['modify_10',['modify',['../LICENSE_8txt.html#a4f5fee3fe655fc467fc80425521837ae',1,'LICENSE.txt']]],
  ['muint_5ft_11',['muint_t',['../typedef_8h.html#a97a723b8aa901db662fdbb09c9cb5cf6',1,'typedef.h']]]
];
