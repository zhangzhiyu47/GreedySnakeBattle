var searchData=
[
  ['settings_0',['Greedy Snake Battle Game Settings',['../group__SetConfig.html',1,'']]],
  ['signal_20capture_1',['Signal capture',['../group__SignalCapture.html',1,'']]],
  ['snake_20battle_20game_20settings_2',['Greedy Snake Battle Game Settings',['../group__SetConfig.html',1,'']]]
];
