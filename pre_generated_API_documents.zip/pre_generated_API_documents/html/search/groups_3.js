var searchData=
[
  ['function_20group_0',['Operating system adaptation function group',['../group__OSAdapt.html',1,'']]]
];
