var searchData=
[
  ['_5fnewt_0',['_newt',['../snakeFullCompat_8c.html#a03c9391690048636f1b54cae2d430774',1,'snakeFullCompat.c']]],
  ['_5foriginal_5ftermios_1',['_original_termios',['../snakeFullCompat_8c.html#a3fb4c30abe9008b077fa04abc9f018ed',1,'snakeFullCompat.c']]]
];
