var searchData=
[
  ['charge_0',['charge',['../LICENSE_8txt.html#aebc511ed3f15c16125b74aa0f22cfa10',1,'LICENSE.txt']]],
  ['claim_1',['CLAIM',['../LICENSE_8txt.html#a6748037be7bf72df72169eafdc8c492e',1,'LICENSE.txt']]],
  ['conditions_2',['conditions',['../LICENSE_8txt.html#a9519688b6bdbbccdcec5fef05966b25b',1,'LICENSE.txt']]],
  ['contract_3',['CONTRACT',['../LICENSE_8txt.html#a808df707d490e1041f54a1d24fbbfaa0',1,'LICENSE.txt']]],
  ['copy_4',['copy',['../LICENSE_8txt.html#aff1d4c6b756ebf691fa44a0904f68658',1,'LICENSE.txt']]]
];
