var searchData=
[
  ['blockwaituserenter_0',['blockWaitUserEnter',['../standardIO_8h.html#a9f7e7b62150367262361204d1e2f74c2',1,'blockWaitUserEnter():&#160;standardIO.c'],['../standardIO_8c.html#a9f7e7b62150367262361204d1e2f74c2',1,'blockWaitUserEnter():&#160;standardIO.c']]]
];
