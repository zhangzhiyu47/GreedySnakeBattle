var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../group__OSAdapt.html#ga1a70bc9ff30788fe7ceeb823942615c8',1,'__attribute__((constructor)):&#160;snakeFullCompat.c'],['../group__OSAdapt.html#ga8cf0124e69d23f31c0efcaba61b9774d',1,'__attribute__((destructor)):&#160;snakeFullCompat.c']]],
  ['_5fsnake_5fgetch_1',['_snake_getch',['../group__OSAdapt.html#ga7718066b167ee7d552fd7e1a987a12e5',1,'_snake_getch(void):&#160;snakeFullCompat.c'],['../group__OSAdapt.html#ga7718066b167ee7d552fd7e1a987a12e5',1,'_snake_getch(void):&#160;snakeFullCompat.c']]],
  ['_5fsnake_5fkbhit_2',['_snake_kbhit',['../group__OSAdapt.html#gabd42cb5b764d0052febbd6cde9d94e8c',1,'_snake_kbhit(void):&#160;snakeFullCompat.c'],['../group__OSAdapt.html#gabd42cb5b764d0052febbd6cde9d94e8c',1,'_snake_kbhit(void):&#160;snakeFullCompat.c']]]
];
