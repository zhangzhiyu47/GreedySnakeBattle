var searchData=
[
  ['license_0',['License',['../LICENSE_8txt.html#aeba0e8be08e24cc3a8c4f3b719ef3d30',1,'LICENSE.txt']]]
];
