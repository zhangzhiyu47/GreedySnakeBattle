var searchData=
[
  ['license_2etxt_0',['LICENSE.txt',['../LICENSE_8txt.html',1,'']]]
];
