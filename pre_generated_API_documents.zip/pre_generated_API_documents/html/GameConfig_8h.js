var GameConfig_8h =
[
    [ "GameConfig", "structGameConfig.html", "structGameConfig" ],
    [ "GameConfig", "GameConfig_8h.html#aa64fdb8a1b9c72973d80bb0dd73c757e", null ]
];