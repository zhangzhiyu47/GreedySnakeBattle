var dir_b2f33c71d4aa5e7af42a1ca61ff5af1b =
[
    [ "GSnakeBInclude", "dir_fd5d877d58f4bba7e1ee672980c1078f.html", "dir_fd5d877d58f4bba7e1ee672980c1078f" ],
    [ "exitApp.c", "exitApp_8c.html", "exitApp_8c" ],
    [ "food.c", "food_8c.html", "food_8c" ],
    [ "gameApplicationStartupRelated.c", "gameApplicationStartupRelated_8c.html", "gameApplicationStartupRelated_8c" ],
    [ "gameMainLogic.c", "gameMainLogic_8c.html", "gameMainLogic_8c" ],
    [ "gameSetConfiguration.c", "gameSetConfiguration_8c.html", "gameSetConfiguration_8c" ],
    [ "gameStartupRelated.c", "gameStartupRelated_8c.html", "gameStartupRelated_8c" ],
    [ "globalVariable.c", "globalVariable_8c.html", "globalVariable_8c" ],
    [ "GreedySnakeBattleGameExternalInterface.c", "GreedySnakeBattleGameExternalInterface_8c.html", "GreedySnakeBattleGameExternalInterface_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "obstacleSnake.c", "obstacleSnake_8c.html", "obstacleSnake_8c" ],
    [ "OfflineModeIntroduction.c", "OfflineModeIntroduction_8c.html", null ],
    [ "painting.c", "painting_8c.html", "painting_8c" ],
    [ "signalCapture.c", "signalCapture_8c.html", "signalCapture_8c" ],
    [ "standardIO.c", "standardIO_8c.html", "standardIO_8c" ],
    [ "terminal.c", "terminal_8c.html", "terminal_8c" ],
    [ "userInterfaceBeforeGameStarts.c", "userInterfaceBeforeGameStarts_8c.html", "userInterfaceBeforeGameStarts_8c" ],
    [ "userSnake.c", "userSnake_8c.html", "userSnake_8c" ],
    [ "wall.c", "wall_8c.html", "wall_8c" ]
];